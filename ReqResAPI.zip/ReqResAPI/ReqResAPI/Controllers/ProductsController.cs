﻿using Microsoft.AspNetCore.Mvc;
using ReqResAPI.Models;

namespace ReqResAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : Controller
    {

        private static List<Product> products = new List<Product>
        {
            new Product { Id = 1, Name = "Laptop", Price = 800.00M },
            new Product { Id = 2, Name = "Smartphone", Price = 500.00M }
        };
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(products);
        }
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var product = products.Find(p => p.Id == id);
            if (product == null)
                return NotFound();
            return Ok(product);
        }
        [HttpPost]
        public IActionResult Post([FromBody] Product product)
        {
            products.Add(product);
            return CreatedAtAction(nameof(Get), new { id = product.Id }, product);
        }
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Product product)
        {
            var index = products.FindIndex(p => p.Id == id);
            if (index == -1)
                return NotFound();
            products[index] = product;
            return NoContent();
        }
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var index = products.FindIndex(p => p.Id == id);
            if (index == -1)
                return NotFound();
            products.RemoveAt(index);
            return NoContent();
        }

    }
}
